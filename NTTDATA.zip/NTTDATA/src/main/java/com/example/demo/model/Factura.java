package com.example.demo.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Factura {
    private String cliente;
    private String ruc;
    private List<Item> items = new ArrayList<>();
    private double neto;
    private double igv;
    private double total;
}
