package com.example.demo.DTO;


import com.example.demo.model.Factura;

public class FacturaResponse {
    private String status;
    private Factura factura;



    public FacturaResponse() {}
    public FacturaResponse(String status, Factura factura) {
        this.status = status;
        this.factura = factura;

    }


    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }


    public Factura getFactura() { return factura; }
    public void setFactura(Factura factura) { this.factura = factura; }


}