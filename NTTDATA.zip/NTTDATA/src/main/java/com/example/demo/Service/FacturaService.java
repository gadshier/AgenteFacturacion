package com.example.demo.Service;

import com.example.demo.model.Factura;
import org.springframework.stereotype.Service;

@Service
public class FacturaService {

    private static final double IGV = 0.18;

    public void calcularTotales(Factura f) {

        double neto = f.getItems().stream()
                .mapToDouble(i -> i.getCantidad() * i.getPrecio())
                .sum();

        double igv = neto * IGV;
        double total = neto + igv;

        f.setNeto(neto);
        f.setIgv(igv);
        f.setTotal(total);
    }

    public String generarHtml(Factura f) {
        return """
        <html>
        <body>
            <h1>Factura</h1>
            <p><b>Cliente:</b> %s</p>
            <p><b>RUC:</b> %s</p>

            <table border='1'>
                <tr><th>Descripción</th><th>Cantidad</th><th>Precio</th><th>Subtotal</th></tr>
                %s
            </table>

            <p><b>Neto:</b> %s</p>
            <p><b>IGV(18%%):</b> %s</p>
            <p><b>Total:</b> %s</p>
        </body>
        </html>
        """.formatted(
                f.getCliente(),
                f.getRuc(),
                renderItems(f),
                f.getNeto(),
                f.getIgv(),
                f.getTotal()
        );
    }

    private String renderItems(Factura f) {
        StringBuilder sb = new StringBuilder();
        f.getItems().forEach(i -> {
            sb.append("<tr>")
                    .append("<td>").append(i.getDescripcion()).append("</td>")
                    .append("<td>").append(i.getCantidad()).append("</td>")
                    .append("<td>").append(i.getPrecio()).append("</td>")
                    .append("<td>").append(i.getCantidad()*i.getPrecio()).append("</td>")
                    .append("</tr>");
        });
        return sb.toString();
    }
}
