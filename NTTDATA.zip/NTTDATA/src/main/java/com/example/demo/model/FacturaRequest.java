package com.example.demo.model;

public class FacturaRequest {
    private String prompt;


    public FacturaRequest() {}


    public FacturaRequest(String prompt) { this.prompt = prompt; }


    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
}