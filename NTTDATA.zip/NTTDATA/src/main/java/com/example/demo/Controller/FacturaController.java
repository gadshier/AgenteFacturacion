package com.example.demo.Controller;

import com.example.demo.DTO.FacturaResponse;
import com.example.demo.Service.FacturaService;
import com.example.demo.Service.GenAiService;
import com.example.demo.model.Factura;
import com.example.demo.model.FacturaRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/factura")
public class FacturaController {

    @Autowired
    private GenAiService genAiService;

    @Autowired
    private FacturaService facturaService;

    @PostMapping("/generar")
    public ResponseEntity<?> generarFactura(@RequestBody FacturaRequest request) {

        // Paso 1: Interpretación del prompt (GENAI simulado)
        Factura factura = genAiService.extraerFacturaDesdePrompt(request.getPrompt());

        // Paso 2: Calcular totales
        facturaService.calcularTotales(factura);


        // Respuesta
        FacturaResponse response = new FacturaResponse("ok", factura);

        return ResponseEntity.ok(response);
    }
}