package com.example.demo.Service;

import com.example.demo.model.Factura;
import com.example.demo.model.Item;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class GenAiService {

    // Patrón para RUC de 11 dígitos
    private static final Pattern RUC_PATTERN = Pattern.compile("\\b(\\d{11})\\b");

    // Patrón para items: "3 laptops a 1500" o "2 teclados a 50"
    private static final Pattern ITEM_PATTERN = Pattern.compile(
            "(\\d+)\\s+([A-Za-zÁÉÍÓÚáéíóúÑñ\\s]+?)\\s+(?:a|@)\\s*(\\d+(?:\\.\\d+)?)",
            Pattern.CASE_INSENSITIVE
    );


    /**
     * Procesa el prompt y extrae datos simulados para generar una factura.
     */
    public Factura extraerFacturaDesdePrompt(String prompt) {
        Factura f = new Factura();
        if (prompt == null) prompt = "";

        // ============================
        // Extraer Cliente
        // ============================
        String cliente = extraerCliente(prompt);
        f.setCliente(cliente == null ? "Cliente Sin Nombre" : cliente);

        // ============================
        // Extraer RUC
        // ============================
        Matcher mRuc = RUC_PATTERN.matcher(prompt.replaceAll("[.,]", ""));
        if (mRuc.find()) {
            f.setRuc(mRuc.group(1));
        } else {
            f.setRuc(generarRucFicticio());
        }

        // ============================
        // Extraer Items
        // ============================
        List<Item> items = new ArrayList<>();
        Matcher m = ITEM_PATTERN.matcher(prompt);

        while (m.find()) {
            try {
                int cantidad = Integer.parseInt(m.group(1).trim());
                String descripcion = m.group(2).trim();
                double precio = Double.parseDouble(m.group(3).trim());
                items.add(new Item(descripcion, cantidad, precio));
            } catch (Exception ignored) {}
        }

        // Intento alternativo para items tipo "3x laptop 1500"
        if (items.isEmpty()) {
            Pattern alt = Pattern.compile(
                    "(\\d+)x?\\s*([A-Za-zÁÉÍÓÚáéíóúÑñ]+)\\s*(\\d+(?:\\.\\d+)?)",
                    Pattern.CASE_INSENSITIVE
            );

            Matcher ma = alt.matcher(prompt);

            while (ma.find()) {
                try {
                    int cantidad = Integer.parseInt(ma.group(1));
                    String descripcion = ma.group(2);
                    double precio = Double.parseDouble(ma.group(3));
                    items.add(new Item(descripcion, cantidad, precio));
                } catch (Exception ignored) {}
            }
        }

        // Item por defecto si no se encuentra nada
        if (items.isEmpty()) {
            items.add(new Item("Producto ejemplo", 1, 100.0));
        }

        f.setItems(items);
        return f;
    }


    // =========================================================================
    // EXTRAER CLIENTE — COMPLETO
    // =========================================================================
    private String extraerCliente(String prompt) {
        if (prompt == null) return null;

        // 1Buscar frases tipo: "para Juan Pérez", "a Carlos Ruiz", "a nombre de Luis"
        Pattern p1 = Pattern.compile(
                "(?:para|a nombre de|a)\\s+([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚñÑ\\s]+?)(?=\\b(por|con|ruc|\\d)\\b|$)",
                Pattern.CASE_INSENSITIVE
        );

        Matcher m1 = p1.matcher(prompt);
        if (m1.find()) {
            return capitalizar(m1.group(1).trim());
        }

        // 2️⃣ Fallback: cualquier cadena con dos o más palabras en mayúscula inicial
        Pattern p2 = Pattern.compile(
                "([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚñÑ]+(?:\\s+[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚñÑ]+)*)"
        );

        Matcher m2 = p2.matcher(prompt);

        if (m2.find()) {
            String nombre = m2.group(1).trim();

            // evitar cosas tipo "Factura Electronica"
            if (!nombre.toLowerCase().contains("factura")) {
                return capitalizar(nombre);
            }
        }

        return null;
    }


    // =========================================================================
    // Generar RUC ficticio (11 dígitos)
    // =========================================================================
    private String generarRucFicticio() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 11; i++) {
            sb.append((int) (Math.random() * 10));
        }
        return sb.toString();
    }

    // =========================================================================
    // Capitalizar nombres
    // =========================================================================
    private String capitalizar(String nombre) {
        String[] partes = nombre.split("\\s+");
        StringBuilder sb = new StringBuilder();

        for (String p : partes) {
            if (p.length() > 1) {
                sb.append(Character.toUpperCase(p.charAt(0)))
                        .append(p.substring(1).toLowerCase());
            } else {
                sb.append(p.toUpperCase());
            }
            sb.append(" ");
        }

        return sb.toString().trim();
    }

}
