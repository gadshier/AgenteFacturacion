package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnalisisPrompt {
    private Decision decision;
    private String razon;
    private String cliente;
    private Integer cantidad;
    private Double precio;
}
