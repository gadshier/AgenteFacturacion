package com.example.demo.model;

public enum Decision {
    GENERAR_FACTURA,
    RECHAZAR,
    CORREGIR_ENTRADA,
    BLOQUEAR_MALICIOSO
}

